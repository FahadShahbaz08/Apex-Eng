# Apex Engineering Manufacturing ERP

An expandable, black-and-white Manufacturing ERP built with Next.js and normal JavaScript. The application starts with no dummy business data.

## Start the source project

Install Node.js LTS, then run:

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

On Windows, `INSTALL_AND_RUN.bat` performs the same steps.

## Recommended first-time setup order

1. Add warehouse racks in **Items & stock > Racks**.
2. Add cash and bank accounts in **Cash & bank**.
3. Add raw materials and finished products in **Items & stock**.
4. Add customers and suppliers/vendors in **Parties**.
5. Create product recipes in **BOM**.
6. Post purchases to receive raw material.
7. Post production to consume BOM materials and receive finished goods.
8. Post sales invoices and party payments.
9. Review overall, party-specific and account-specific ledgers.

## Manufacturing behavior

A BOM defines a standard finished quantity, any number of raw-material lines, preferred issue racks, and any number of cost components. Default examples supported by the UI are labour, electricity, machine cost and packing; custom rows can be added freely.

When production is posted, the engine:

- multiplies every BOM requirement by the requested production quantity;
- validates available material in each selected rack;
- subtracts the material quantities from those racks;
- calculates material cost using current weighted-average item cost;
- scales every BOM cost component and includes additional batch cost;
- calculates total and per-unit production cost;
- adds finished goods to the receiving rack;
- updates the finished product's weighted-average cost;
- creates a balanced production journal and immutable audit record.

## Source structure

```text
app/
  globals.css              Monochrome responsive design system
  layout.js                Application metadata and root layout
  page.js                  Provider and application entry point
components/
  AppShell.js              Navigation, themes and screen routing
  ERPContext.js            Persistent versioned ERP state
  UI.js                    Reusable UI primitives
  forms/
    CommonForms.js         Item, party, rack, account and stock forms
    TransactionForms.js    BOM, production, purchase, sale and finance forms
  screens/
    Masters.js             Item/stock/rack, party and BOM screens
    Operations.js          Dashboard, production, purchase and sales screens
    Finance.js             Ledgers, cash/bank, reports, expenses and settings
lib/
  schema.js                Empty schema, migration and ID helpers
  erp.js                   Stock, costing, posting and accounting engine
```

## Implemented modules

- Dashboard and first-time setup guide
- Raw-material, finished-goods and consumable item master
- Rack, zone and warehouse management
- Rack stock transfers and controlled adjustments
- Immutable item stock-movement ledger
- Customer, supplier and dual-role party master
- BOM versions with unlimited materials and cost components
- Production posting and finished-product costing
- Purchase management and vendor payables
- Sales invoices, COGS, customer receivables and print/PDF
- Customer receipts and vendor payments
- Overall general ledger
- Customer/vendor-specific ledger with running balance
- Account-specific ledger
- Cash, bank and wallet accounts
- Daily and factory expenses
- Stock, sales, purchase, production, party, audit and P&L reports
- CSV exports
- User/role definitions
- Full JSON backup and restore
- Light and dark monochrome themes

## Storage and production deployment

This source is a local-first functional ERP prototype. Data is stored in browser local storage and can be exported as a complete JSON backup. For multi-user production use, preserve the posting functions in `lib/erp.js` but move persistence to a transactional database/API. Add authenticated server sessions, server-enforced roles, document attachments, period locking, database backups, tax rules and concurrency controls.
