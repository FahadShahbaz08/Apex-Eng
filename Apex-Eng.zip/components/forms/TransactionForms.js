"use client";

import { useMemo, useState } from "react";
import { useERP } from "../ERPContext";
import { addBOM, money, postExpense, postPayment, postProduction, postPurchase, postSale, stockFor } from "../../lib/erp";
import { dateNow, id } from "../../lib/schema";
import { Button, ErrorText, Field, FormActions, Modal } from "../UI";

const emptyLine = () => ({ itemId: "", rackId: "", quantity: 1, rate: 0 });

function LinesEditor({ lines, setLines, items, racks, sale = false }) {
  const update = (index, key, value) => setLines(lines.map((line, i) => i === index ? { ...line, [key]: value, ...(key === "itemId" ? { rate: items.find(x => x.id === value)?.[sale ? "saleRate" : "cost"] || 0 } : {}) } : line));
  return <div className="line-editor"><div className="line-grid line-head"><span>Item</span><span>Rack</span><span>Quantity</span><span>Rate</span><span>Amount</span><span /></div>{lines.map((line, index) => <div className="line-grid" key={index}><select value={line.itemId} onChange={e => update(index, "itemId", e.target.value)} required><option value="">Select item</option>{items.map(i => <option key={i.id} value={i.id}>{i.sku} — {i.name}</option>)}</select><select value={line.rackId} onChange={e => update(index, "rackId", e.target.value)} required><option value="">Select rack</option>{racks.map(r => <option key={r.id} value={r.id}>{r.code}</option>)}</select><input type="number" min="0.01" step="0.01" value={line.quantity} onChange={e => update(index, "quantity", e.target.value)} required /><input type="number" min="0" step="0.01" value={line.rate} onChange={e => update(index, "rate", e.target.value)} required /><b>{money(Number(line.quantity) * Number(line.rate))}</b><button type="button" onClick={() => lines.length > 1 && setLines(lines.filter((_, i) => i !== index))}>×</button></div>)}<button className="add-row" type="button" onClick={() => setLines([...lines, emptyLine()])}>+ Add another line</button></div>;
}

export function PurchaseForm({ close }) {
  const { state, mutate } = useERP();
  const [lines, setLines] = useState([emptyLine()]);
  const [discount, setDiscount] = useState(0);
  const [charges, setCharges] = useState(0);
  const [paid, setPaid] = useState(0);
  const [error, setError] = useState("");
  const total = lines.reduce((s, l) => s + Number(l.quantity) * Number(l.rate), 0) - Number(discount) + Number(charges);
  const submit = (e) => { e.preventDefault(); try { const f = Object.fromEntries(new FormData(e.currentTarget)); mutate(s => postPurchase(s, { ...f, lines, discount, charges, paid })); close(); } catch (err) { setError(err.message); } };
  return <Modal title="Post purchase invoice" eyebrow="STOCK IN + VENDOR PAYABLE" close={close} wide><form onSubmit={submit}><div className="form-grid three"><Field label="Supplier"><select name="partyId" required><option value="">Select supplier</option>{state.parties.filter(p => ["Supplier", "Both"].includes(p.type)).map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></Field><Field label="Purchase date"><input name="date" type="date" defaultValue={dateNow()} required /></Field><Field label="Supplier invoice"><input name="supplierInvoice" required /></Field><Field label="Due date"><input name="dueDate" type="date" /></Field><Field label="Paid now"><input value={paid} onChange={e => setPaid(e.target.value)} type="number" min="0" max={total} step="0.01" /></Field><Field label="Paid from"><select name="accountId"><option value="">Credit only</option>{state.accounts.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}</select></Field></div><LinesEditor lines={lines} setLines={setLines} items={state.items.filter(i => i.type !== "Finished Good")} racks={state.racks} /><div className="transaction-foot"><div className="form-grid two"><Field label="Discount"><input value={discount} onChange={e => setDiscount(e.target.value)} type="number" min="0" /></Field><Field label="Freight / charges"><input value={charges} onChange={e => setCharges(e.target.value)} type="number" min="0" /></Field></div><div className="document-total"><span>Purchase total</span><strong>{money(total)}</strong><small>Remaining payable: {money(total - Number(paid))}</small></div></div><ErrorText>{error}</ErrorText><FormActions close={close} submit="Post purchase" /></form></Modal>;
}

export function SaleForm({ close }) {
  const { state, mutate } = useERP();
  const [lines, setLines] = useState([emptyLine()]);
  const [discount, setDiscount] = useState(0), [tax, setTax] = useState(0), [charges, setCharges] = useState(0), [paid, setPaid] = useState(0), [error, setError] = useState("");
  const subtotal = lines.reduce((s, l) => s + Number(l.quantity) * Number(l.rate), 0);
  const total = subtotal - Number(discount) + Number(tax) + Number(charges);
  const submit = (e) => { e.preventDefault(); try { const f = Object.fromEntries(new FormData(e.currentTarget)); mutate(s => postSale(s, { ...f, lines, discount, tax, charges, paid })); close(); } catch (err) { setError(err.message); } };
  return <Modal title="Post sales invoice" eyebrow="STOCK OUT + CUSTOMER RECEIVABLE" close={close} wide><form onSubmit={submit}><div className="form-grid three"><Field label="Customer"><select name="partyId" required><option value="">Select customer</option>{state.parties.filter(p => ["Customer", "Both"].includes(p.type)).map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></Field><Field label="Invoice date"><input name="date" type="date" defaultValue={dateNow()} required /></Field><Field label="Due date"><input name="dueDate" type="date" /></Field><Field label="Received now"><input value={paid} onChange={e => setPaid(e.target.value)} type="number" min="0" max={total} step="0.01" /></Field><Field label="Received in"><select name="accountId"><option value="">Credit only</option>{state.accounts.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}</select></Field><Field label="Customer reference"><input name="customerReference" /></Field></div><LinesEditor lines={lines} setLines={setLines} items={state.items.filter(i => i.type === "Finished Good")} racks={state.racks} sale /><div className="transaction-foot"><div className="form-grid three"><Field label="Discount"><input value={discount} onChange={e => setDiscount(e.target.value)} type="number" min="0" /></Field><Field label="Tax"><input value={tax} onChange={e => setTax(e.target.value)} type="number" min="0" /></Field><Field label="Other charges"><input value={charges} onChange={e => setCharges(e.target.value)} type="number" min="0" /></Field></div><div className="document-total"><span>Invoice total</span><strong>{money(total)}</strong><small>Remaining receivable: {money(total - Number(paid))}</small></div></div><ErrorText>{error}</ErrorText><FormActions close={close} submit="Post invoice" /></form></Modal>;
}

export function BOMForm({ close }) {
  const { state, mutate } = useERP();
  const raw = state.items.filter(i => ["Raw Material", "Consumable"].includes(i.type));
  const products = state.items.filter(i => i.type === "Finished Good");
  const [lines, setLines] = useState([{ itemId: "", rackId: "", quantity: 1 }]);
  const [costs, setCosts] = useState([{ name: "Labour", amount: 0 }, { name: "Electricity", amount: 0 }, { name: "Machine Cost", amount: 0 }, { name: "Packing", amount: 0 }]);
  const [error, setError] = useState("");
  const updateLine = (index, key, value) => setLines(lines.map((x, i) => i === index ? { ...x, [key]: value } : x));
  const updateCost = (index, key, value) => setCosts(costs.map((x, i) => i === index ? { ...x, [key]: value } : x));
  const submit = (e) => { e.preventDefault(); try { const f = Object.fromEntries(new FormData(e.currentTarget)); if (!lines.length || lines.some(l => !l.itemId || Number(l.quantity) <= 0)) throw new Error("Every BOM material line needs an item and quantity."); mutate(s => addBOM(s, { ...f, lines, costs: costs.filter(c => c.name && Number(c.amount) >= 0) })); close(); } catch (err) { setError(err.message); } };
  return <Modal title="Create Bill of Materials" eyebrow="PRODUCT RECIPE & COSTING" close={close} wide><form onSubmit={submit}><div className="form-grid three"><Field label="BOM name"><input name="name" placeholder="Tractor Hub Standard" required /></Field><Field label="Finished product"><select name="productId" required><option value="">Select product</option>{products.map(p => <option key={p.id} value={p.id}>{p.sku} — {p.name}</option>)}</select></Field><Field label="BOM version"><input name="version" defaultValue="1.0" /></Field><Field label="Standard output quantity"><input name="outputQty" type="number" min="0.01" step="0.01" defaultValue="1" required /></Field><Field label="Notes"><input name="notes" /></Field></div><div className="section-label"><span>Raw materials for the standard output</span><button type="button" onClick={() => setLines([...lines, { itemId: "", rackId: "", quantity: 1 }])}>+ Material</button></div>{lines.map((line, i) => <div className="bom-row" key={i}><select value={line.itemId} onChange={e => updateLine(i, "itemId", e.target.value)} required><option value="">Select raw material</option>{raw.map(x => <option key={x.id} value={x.id}>{x.sku} — {x.name}</option>)}</select><input type="number" min="0.01" step="0.01" value={line.quantity} onChange={e => updateLine(i, "quantity", e.target.value)} /><select value={line.rackId} onChange={e => updateLine(i, "rackId", e.target.value)}><option value="">Preferred issue rack</option>{state.racks.map(r => <option value={r.id} key={r.id}>{r.code}</option>)}</select><button type="button" onClick={() => lines.length > 1 && setLines(lines.filter((_, n) => n !== i))}>×</button></div>)}<div className="section-label"><span>Conversion costs for the standard output</span><button type="button" onClick={() => setCosts([...costs, { name: "", amount: 0 }])}>+ Custom cost</button></div>{costs.map((cost, i) => <div className="cost-row" key={i}><input value={cost.name} onChange={e => updateCost(i, "name", e.target.value)} placeholder="Cost name" /><input type="number" min="0" step="0.01" value={cost.amount} onChange={e => updateCost(i, "amount", e.target.value)} /><span>per standard output</span><button type="button" onClick={() => setCosts(costs.filter((_, n) => n !== i))}>×</button></div>)}<ErrorText>{error}</ErrorText><FormActions close={close} submit="Save BOM" /></form></Modal>;
}

export function ProductionForm({ close }) {
  const { state, mutate } = useERP();
  const [bomId, setBomId] = useState(""), [quantity, setQuantity] = useState(1), [issueRacks, setIssueRacks] = useState({}), [error, setError] = useState("");
  const bom = state.boms.find(b => b.id === bomId);
  const estimate = useMemo(() => { if (!bom) return null; const multiplier = Number(quantity) / Number(bom.outputQty); const materials = bom.lines.map(line => { const item = state.items.find(i => i.id === line.itemId); const required = Number(line.quantity) * multiplier; return { ...line, item, required, cost: required * Number(item?.cost || 0) }; }); const materialCost = materials.reduce((s, x) => s + x.cost, 0); const conversion = bom.costs.reduce((s, x) => s + Number(x.amount) * multiplier, 0); return { materials, materialCost, conversion, total: materialCost + conversion }; }, [bom, quantity, state.items]);
  const submit = (e) => { e.preventDefault(); try { const f = Object.fromEntries(new FormData(e.currentTarget)); mutate(s => postProduction(s, { ...f, bomId, quantity, issueRacks })); close(); } catch (err) { setError(err.message); } };
  return <Modal title="Post production order" eyebrow="BOM CONSUMPTION + FINISHED OUTPUT" close={close} wide><form onSubmit={submit}>
    <div className="form-grid three">
      <Field label="BOM / recipe"><select value={bomId} onChange={e => { setBomId(e.target.value); const selected = state.boms.find(b => b.id === e.target.value); setQuantity(selected?.outputQty || 1); }} required><option value="">Select BOM</option>{state.boms.filter(b => b.active).map(b => <option key={b.id} value={b.id}>{b.name} · v{b.version}</option>)}</select></Field>
      <Field label="Production date"><input name="date" type="date" defaultValue={dateNow()} required /></Field>
      <Field label="Quantity to produce"><input value={quantity} onChange={e => setQuantity(e.target.value)} type="number" min="0.01" step="0.01" required /></Field>
      <Field label="Finished goods rack"><select name="outputRackId" required><option value="">Receiving rack</option>{state.racks.map(r => <option key={r.id} value={r.id}>{r.code} — {r.name}</option>)}</select></Field>
      <Field label="Additional batch cost"><input name="additionalCost" type="number" min="0" step="0.01" defaultValue="0" /></Field>
      <Field label="Batch note"><input name="note" /></Field>
    </div>
    {estimate && <>
      <div className="section-label"><span>Automatic material issue</span><b>{bom.productId && state.items.find(i => i.id === bom.productId)?.name}</b></div>
      <div className="material-preview">{estimate.materials.map(line => {
        const selectedRack = issueRacks[line.itemId] || line.rackId || "";
        return <div key={line.itemId}><div><strong>{line.item?.name}</strong><small>Required: {line.required} {line.item?.unit} · Available: {stockFor(state, line.itemId, selectedRack)} · {money(line.cost)}</small></div><select value={selectedRack} onChange={e => setIssueRacks({ ...issueRacks, [line.itemId]: e.target.value })} required><option value="">Issue from rack</option>{state.racks.map(r => <option value={r.id} key={r.id}>{r.code}</option>)}</select></div>;
      })}</div>
      <div className="cost-summary"><div><span>Raw material</span><b>{money(estimate.materialCost)}</b></div>{bom.costs.map(c => <div key={c.name}><span>{c.name}</span><b>{money(Number(c.amount) * Number(quantity) / Number(bom.outputQty))}</b></div>)}<div className="grand"><span>Estimated total / unit</span><b>{money(estimate.total)} / {money(estimate.total / Number(quantity))}</b></div></div>
    </>}
    <ErrorText>{error}</ErrorText><FormActions close={close} submit="Post production" />
  </form></Modal>;
}

export function PaymentForm({ close }) {
  const { state, mutate } = useERP();
  const [direction, setDirection] = useState("Receipt"), [error, setError] = useState("");
  const submit = (e) => { e.preventDefault(); try { mutate(s => postPayment(s, { ...Object.fromEntries(new FormData(e.currentTarget)), direction })); close(); } catch (err) { setError(err.message); } };
  return <Modal title="Record party payment" eyebrow="CUSTOMER RECEIPT / VENDOR PAYMENT" close={close}><form onSubmit={submit}><div className="segmented"><button type="button" className={direction === "Receipt" ? "active" : ""} onClick={() => setDirection("Receipt")}>Customer receipt</button><button type="button" className={direction === "Payment" ? "active" : ""} onClick={() => setDirection("Payment")}>Vendor payment</button></div><div className="form-grid two"><Field label="Party"><select name="partyId" required><option value="">Select party</option>{state.parties.filter(p => direction === "Receipt" ? ["Customer", "Both"].includes(p.type) : ["Supplier", "Both"].includes(p.type)).map(p => <option value={p.id} key={p.id}>{p.name}</option>)}</select></Field><Field label="Date"><input name="date" type="date" defaultValue={dateNow()} required /></Field><Field label="Amount"><input name="amount" type="number" min="0.01" step="0.01" required /></Field><Field label="Cash / bank"><select name="accountId" required><option value="">Select account</option>{state.accounts.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}</select></Field><Field label="Reference"><input name="reference" /></Field><Field label="Description"><input name="description" /></Field></div><ErrorText>{error}</ErrorText><FormActions close={close} submit={`Post ${direction.toLowerCase()}`} /></form></Modal>;
}

export function ExpenseForm({ close }) {
  const { state, mutate } = useERP(); const [error, setError] = useState("");
  const submit = e => { e.preventDefault(); try { mutate(s => postExpense(s, Object.fromEntries(new FormData(e.currentTarget)))); close(); } catch (err) { setError(err.message); } };
  return <Modal title="Record expense" eyebrow="OPERATING / FACTORY COST" close={close}><form onSubmit={submit}><div className="form-grid two"><Field label="Date"><input name="date" type="date" defaultValue={dateNow()} required /></Field><Field label="Category"><input name="category" list="expense-categories" required /><datalist id="expense-categories"><option>Salary</option><option>Electricity</option><option>Fuel</option><option>Transport</option><option>Office</option><option>Factory</option></datalist></Field><Field label="Description"><input name="description" required /></Field><Field label="Amount"><input name="amount" type="number" min="0.01" step="0.01" required /></Field><Field label="Paid from"><select name="accountId" required><option value="">Select account</option>{state.accounts.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}</select></Field><Field label="Payee"><input name="payee" /></Field></div><ErrorText>{error}</ErrorText><FormActions close={close} submit="Post expense" /></form></Modal>;
}

export function UserForm({ close }) {
  const { state, mutate } = useERP(); const [error, setError] = useState("");
  const submit = e => { e.preventDefault(); try { const values = Object.fromEntries(new FormData(e.currentTarget)); mutate(s => { s.users.push({ id: id("USR"), ...values, active: true }); s.audit.unshift({ id: id("AUD"), at: new Date().toISOString(), user: "Administrator", action: `Created user ${values.name}` }); }); close(); } catch (err) { setError(err.message); } };
  return <Modal title="Add system user" eyebrow="USER PERMISSIONS" close={close}><form onSubmit={submit}><div className="form-grid two"><Field label="Full name"><input name="name" required /></Field><Field label="Email / username"><input name="email" required /></Field><Field label="Role"><select name="role">{Object.keys(state.settings.roles).map(role => <option key={role}>{role}</option>)}</select></Field><Field label="Department"><input name="department" /></Field></div><p className="form-note">This source prototype stores user definitions locally. Production authentication must be connected to a secure server-side identity provider.</p><ErrorText>{error}</ErrorText><FormActions close={close} submit="Create user" /></form></Modal>;
}
