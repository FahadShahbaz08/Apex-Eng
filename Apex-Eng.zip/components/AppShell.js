"use client";

import { useEffect, useState } from "react";
import { useERP } from "./ERPContext";
import { Button } from "./UI";
import { AccountForm, ItemForm, PartyForm, RackForm, StockActionForm } from "./forms/CommonForms";
import { BOMForm, ExpenseForm, PaymentForm, ProductionForm, PurchaseForm, SaleForm, UserForm } from "./forms/TransactionForms";
import { BOMScreen, ItemsStockScreen, PartiesScreen } from "./screens/Masters";
import { DashboardScreen, ProductionScreen, PurchasesScreen, SalesScreen } from "./screens/Operations";
import { CashBankScreen, ExpensesScreen, LedgersScreen, ReportsScreen, SettingsScreen } from "./screens/Finance";

const pages = [
  ["Dashboard", "D"], ["Items & stock", "I"], ["Parties", "P"], ["BOM", "B"], ["Production", "M"],
  ["Purchases", "R"], ["Sales & invoices", "S"], ["Cash & bank", "C"], ["Ledgers", "L"],
  ["Expenses", "E"], ["Reports", "T"], ["Settings & backup", "G"],
];

export default function AppShell() {
  const { state, ready } = useERP();
  const [page, setPage] = useState("Dashboard");
  const [modal, setModal] = useState("");
  const [theme, setTheme] = useState("light");
  const [ledgerParty, setLedgerParty] = useState("");

  useEffect(() => { const saved = localStorage.getItem("apex-erp-theme"); if (saved) setTheme(saved); }, []);
  useEffect(() => { document.documentElement.dataset.theme = theme; localStorage.setItem("apex-erp-theme", theme); }, [theme]);
  const navigate = (next) => setPage(next);
  const goLedger = (partyId) => { setLedgerParty(partyId); setPage("Ledgers"); };

  if (!ready) return <div className="loading">Loading Apex Engineering ERP…</div>;
  return <div className="app-shell"><aside className="sidebar"><div className="brand"><span>AE</span><div><strong>APEX</strong><small>ENGINEERING ERP</small></div></div><nav>{pages.map(([name, icon]) => <button key={name} className={page === name ? "active" : ""} onClick={() => navigate(name)}><i>{icon}</i><span>{name}</span></button>)}</nav><footer><button onClick={() => setTheme(theme === "light" ? "dark" : "light")}>{theme === "light" ? "Switch to dark" : "Switch to light"}</button><div><span>AD</span><section><b>Administrator</b><small>Full access</small></section></div></footer></aside><main><header className="topbar"><div><p>APEX ENGINEERING</p><b>{page}</b></div><div><Button variant="outline" onClick={() => setModal("payment")}>Receipt / payment</Button><Button onClick={() => setModal("sale")}>+ Sales invoice</Button></div></header><section className="content">{page === "Dashboard" && <DashboardScreen open={setModal} navigate={navigate} />}{page === "Items & stock" && <ItemsStockScreen open={setModal} />}{page === "Parties" && <PartiesScreen open={setModal} goLedger={goLedger} />}{page === "BOM" && <BOMScreen open={setModal} />}{page === "Production" && <ProductionScreen open={setModal} />}{page === "Purchases" && <PurchasesScreen open={setModal} />}{page === "Sales & invoices" && <SalesScreen open={setModal} />}{page === "Cash & bank" && <CashBankScreen open={setModal} />}{page === "Ledgers" && <LedgersScreen initialPartyId={ledgerParty} clearInitial={() => setLedgerParty("")} />}{page === "Expenses" && <ExpensesScreen open={setModal} />}{page === "Reports" && <ReportsScreen />}{page === "Settings & backup" && <SettingsScreen open={setModal} />}</section></main>{modal === "item" && <ItemForm close={() => setModal("")} />}{modal === "party" && <PartyForm close={() => setModal("")} />}{modal === "rack" && <RackForm close={() => setModal("")} />}{modal === "account" && <AccountForm close={() => setModal("")} />}{modal === "adjustment" && <StockActionForm close={() => setModal("")} />}{modal === "transfer" && <StockActionForm close={() => setModal("")} mode="transfer" />}{modal === "bom" && <BOMForm close={() => setModal("")} />}{modal === "production" && <ProductionForm close={() => setModal("")} />}{modal === "purchase" && <PurchaseForm close={() => setModal("")} />}{modal === "sale" && <SaleForm close={() => setModal("")} />}{modal === "payment" && <PaymentForm close={() => setModal("")} />}{modal === "expense" && <ExpenseForm close={() => setModal("")} />}{modal === "user" && <UserForm close={() => setModal("")} />}</div>;
}
