"use client";

import { createContext, useContext, useEffect, useState } from "react";
import { createEmptyERP, migrateERP } from "../lib/schema";

const ERPContext = createContext(null);
const STORAGE_KEY = "apex-engineering-erp-v4";

export function ERPProvider({ children }) {
  const [state, setState] = useState(createEmptyERP);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try { setState(migrateERP(JSON.parse(saved))); } catch { setState(createEmptyERP()); }
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (ready) localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state, ready]);

  const mutate = (operation) => {
    const next = structuredClone(state);
    const result = operation(next);
    setState(next);
    return result;
  };

  const replace = (next) => setState(migrateERP(next));
  const clear = () => setState(createEmptyERP());

  return <ERPContext.Provider value={{ state, mutate, replace, clear, ready }}>{children}</ERPContext.Provider>;
}

export const useERP = () => {
  const context = useContext(ERPContext);
  if (!context) throw new Error("useERP must be used inside ERPProvider");
  return context;
};
