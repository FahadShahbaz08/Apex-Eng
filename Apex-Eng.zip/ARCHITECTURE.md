# Architecture and extension guide

## Design principle

Documents are the source of truth. Current stock, cash/bank balances, party balances, general ledgers and reports are derived from posted documents and immutable movements. They are never maintained as disconnected editable totals.

## Layers

1. `lib/schema.js` defines the versioned empty data contract and migrations.
2. `lib/erp.js` contains pure posting and costing operations. Every business rule belongs here.
3. `components/ERPContext.js` is the current persistence adapter. It can be replaced by API calls without redesigning screens.
4. `components/forms` validate and submit business documents.
5. `components/screens` read derived operational and accounting views.
6. `components/UI.js` and `app/globals.css` form the reusable monochrome design system.

## Core invariants

- Stock is the sum of signed rack-level `stockMovements`.
- Posted stock is not edited directly.
- Negative rack stock is blocked unless the system policy explicitly enables it.
- Every financial document produces a balanced journal.
- Party ledger rows are generated from source documents and payments.
- BOMs retain versions; production stores a BOM snapshot for historical traceability.
- Finished-product cost uses weighted average after production receipt.
- Duplicate SKU, rack, party, account, BOM-version and supplier-invoice identifiers are blocked.
- Audit records are appended for every master-data and posting action.

## Moving to a server database

Create repository interfaces for masters, documents, stock movements, journals and audit events. Execute each posting function inside a single database transaction. Add optimistic locking or database row locks around stock validation and weighted-average costing. Never let the browser submit calculated journal rows as authoritative data; recalculate on the server.

Recommended production tables:

- companies, branches, warehouses, racks
- items, units, categories, item_suppliers
- parties, party_contacts, party_addresses
- boms, bom_versions, bom_material_lines, bom_cost_lines
- purchases, purchase_lines, purchase_returns
- sales_invoices, sales_lines, sales_returns
- production_orders, production_materials, production_costs
- stock_movements
- financial_accounts, journal_entries, journal_lines
- party_ledger_entries, payment_allocations
- expenses, attachments
- users, roles, permissions
- periods, audit_events, backups

## Safe future modules

New modules should post through the same engines rather than altering balances. Useful extensions include multi-branch transfers, purchase/sales returns, quotation and sales-order workflows, quality inspection, machine maintenance, payroll, barcode scanning, serial/batch tracking, tax filing, bank reconciliation and API integrations.
